/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MenuUsuario extends JFrame {

    private Reserva reservaActual;

    public MenuUsuario(Usuario usuario) {
        this.reservaActual = null;

        setTitle("📋 Menú Principal - SmartParking");
        setSize(450, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblBienvenida = new JLabel("¡Hola, " + usuario.getNombre() + "! 👋", SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 18));
        lblBienvenida.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 10, 10));

        JButton btnReservar = new JButton("🅿️ Reservar Estacionamiento");
        JButton btnPagar = new JButton("💳 Realizar Pago");
        JButton btnNotificacion = new JButton("🔔 Verificar Notificación");
        JButton btnSalir = new JButton("🚪 Cerrar Sesión");

        panelBotones.add(btnReservar);
        panelBotones.add(btnPagar);
        panelBotones.add(btnNotificacion);
        panelBotones.add(btnSalir);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 40, 30, 40));

        add(lblBienvenida, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);

        btnReservar.addActionListener(e -> {
            dispose();
            ReservaEstacionamiento ventanaReserva = new ReservaEstacionamiento(usuario);
            ventanaReserva.setVisible(true);

            ventanaReserva.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                    Reserva res = ventanaReserva.getReserva();
                    if (res != null) {
                        reservaActual = res;
                        JOptionPane.showMessageDialog(null, "🎉 Reserva guardada en el menú.");
                    }
                }
            });
        });

        btnPagar.addActionListener((ActionEvent e) -> {
            if (reservaActual == null) {
                JOptionPane.showMessageDialog(MenuUsuario.this, "⛔ Primero debes realizar una reserva para pagar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            } else {
                dispose();
                new PagoEstacionamiento(usuario, reservaActual).setVisible(true);
            }
        });

        btnNotificacion.addActionListener((ActionEvent e) -> {
            if (reservaActual == null) {
                JOptionPane.showMessageDialog(MenuUsuario.this, "⛔ No tienes reservas activas.", "Aviso", JOptionPane.WARNING_MESSAGE);
            } else {
                dispose();
                new NotificacionReserva(usuario, reservaActual).setVisible(true);
            }
        });

        btnSalir.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "👋 Sesión cerrada. ¡Hasta pronto!", "Adiós", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            new PantallaInicio().setVisible(true);
        });
    }
}
