/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class LoginUsuario extends JFrame {

    private final JTextField txtCorreo;
    private final JPasswordField txtPass;
    private final JButton btnIngresar;
    private final JButton btnVolver;

    private final ArrayList<Usuario> usuariosRegistrados = new ArrayList<>();

    public LoginUsuario() {
        setTitle("🔐 Iniciar Sesión - SmartParking");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 10, 10));

        usuariosRegistrados.add(new Usuario("Karol", "karol@email.com", "1234"));

        txtCorreo = new JTextField();
        txtPass = new JPasswordField();

        btnIngresar = new JButton("🚪 Ingresar");
        btnVolver = new JButton("🔙 Volver");

        add(new JLabel("📧 Correo:"));
        add(txtCorreo);
        add(new JLabel("🔑 Contraseña:"));
        add(txtPass);
        add(btnIngresar);
        add(btnVolver);

        btnIngresar.addActionListener((ActionEvent e) -> {
            String correo = txtCorreo.getText();
            String pass = new String(txtPass.getPassword());

            Usuario usuarioEncontrado = null;
            for (Usuario u : usuariosRegistrados) {
                if (u.validarLogin(correo, pass)) {
                    usuarioEncontrado = u;
                    break;
                }
            }

            if (usuarioEncontrado != null) {
                JOptionPane.showMessageDialog(this, "🎉 Bienvenida de nuevo, " + usuarioEncontrado.getNombre() + " 💫", "Acceso correcto", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new MenuUsuario(usuarioEncontrado).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "❌ Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnVolver.addActionListener((ActionEvent e) -> {
            dispose();
            new PantallaInicio().setVisible(true);
        });
    }
}
