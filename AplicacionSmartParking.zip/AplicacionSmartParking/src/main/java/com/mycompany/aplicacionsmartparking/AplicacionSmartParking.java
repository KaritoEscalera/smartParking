/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */

/**
 *
 * @author claud
 */
import javax.swing.SwingUtilities;

/**
 *
 * @author claud
 */
public class AplicacionSmartParking {

    public static void main(String[] args) {
        System.out.println("🚗 Bienvenido a SmartParking App 🅿️");
        System.out.println("Iniciando aplicación... 🔄");

        // Inicia la interfaz gráfica en el hilo de eventos de Swing
        SwingUtilities.invokeLater(() -> {
            // Puedes cambiar esta línea por RegistroLogin o RegistroUsuario si lo prefieres
            LoginUsuario login = new LoginUsuario();
            login.setVisible(true);
        });
    }
}
