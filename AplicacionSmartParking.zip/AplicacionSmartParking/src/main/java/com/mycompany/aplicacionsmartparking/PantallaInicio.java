/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PantallaInicio extends JFrame {

    private final JButton btnLogin;
    private final JButton btnRegistro;

    public PantallaInicio() {
        setTitle("🅿️ SmartParking - Inicio");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lblTitulo = new JLabel("🚗 Bienvenida a SmartParking", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        btnLogin = new JButton("🔐 Iniciar Sesión");
        btnRegistro = new JButton("📝 Registrarse");

        JPanel panelBotones = new JPanel(new GridLayout(2, 1, 10, 10));
        panelBotones.add(btnLogin);
        panelBotones.add(btnRegistro);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(0, 50, 30, 50));

        add(lblTitulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);

        btnLogin.addActionListener((ActionEvent e) -> {
            dispose();
            new LoginUsuario().setVisible(true);
        });

        btnRegistro.addActionListener((ActionEvent e) -> {
            dispose();
            new RegistroUsuario().setVisible(true);
        });
    }

    @Override
    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

