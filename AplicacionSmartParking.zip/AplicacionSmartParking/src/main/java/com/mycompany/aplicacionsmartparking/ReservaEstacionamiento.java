/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ReservaEstacionamiento extends JFrame {

    private final JComboBox<String> comboEspacios;
    private final JTextField txtHoras;
    private final JButton btnReservar;
    private final JButton btnVolver;

    private final ArrayList<Estacionamiento> espaciosDisponibles = new ArrayList<>();
    private Reserva reservaCreada;

    public ReservaEstacionamiento(Usuario usuario) {

        for (int i = 1; i <= 5; i++) {
            espaciosDisponibles.add(new Estacionamiento(i));
        }

        setTitle("🅿️ Reserva de Estacionamiento");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 10, 10));

        comboEspacios = new JComboBox<>();
        for (Estacionamiento esp : espaciosDisponibles) {
            comboEspacios.addItem("Espacio #" + esp.getId());
        }

        txtHoras = new JTextField();
        btnReservar = new JButton("✅ Confirmar Reserva");
        btnVolver = new JButton("🔙 Volver al Menú");

        add(new JLabel("🅿️ Selecciona un espacio:"));
        add(comboEspacios);
        add(new JLabel("⏳ Duración (horas):"));
        add(txtHoras);
        add(btnReservar);
        add(btnVolver);

        btnReservar.addActionListener((ActionEvent e) -> {
            int index = comboEspacios.getSelectedIndex();
            Estacionamiento espacio = espaciosDisponibles.get(index);
            String horasTxt = txtHoras.getText();

            try {
                int horas = Integer.parseInt(horasTxt);
                if (horas <= 0) throw new NumberFormatException();

                reservaCreada = new Reserva(usuario, espacio, horas);
                JOptionPane.showMessageDialog(this, "🎉 ¡Reserva realizada!\n\n" + reservaCreada, "Reserva Exitosa", JOptionPane.INFORMATION_MESSAGE);
                this.dispose();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "⚠️ Ingresa un número válido de horas.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnVolver.addActionListener((ActionEvent e) -> {
            dispose();
            new MenuUsuario(usuario).setVisible(true);
        });
    }

    public Reserva getReserva() {
        return reservaCreada;
    }
}
