/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
public abstract class Pago {
    protected double monto;
    protected String fecha;

    public Pago(double monto, String fecha) {
        this.monto = monto;
        this.fecha = fecha;
    }

    public abstract void procesarPago();

    public double getMonto() {
        return monto;
    }

    public String getFecha() {
        return fecha;
    }
}
