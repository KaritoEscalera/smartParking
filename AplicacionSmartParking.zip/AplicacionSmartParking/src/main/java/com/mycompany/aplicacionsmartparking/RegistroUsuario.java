/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegistroUsuario extends JFrame {

    private final JTextField txtNombre;
    private final JTextField txtCorreo;
    private final JPasswordField txtPass;
    private final JButton btnRegistrar;
    private final JButton btnVolver;

    public RegistroUsuario() {
        setTitle("📝 Registro de Usuario - SmartParking");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2, 10, 10));

        JLabel lblTitulo = new JLabel("🧑 Crear una nueva cuenta", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(new Color(0, 102, 204));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        txtNombre = new JTextField();
        txtCorreo = new JTextField();
        txtPass = new JPasswordField();

        btnRegistrar = new JButton("✅ Registrar");
        btnVolver = new JButton("🔙 Volver");

        add(new JLabel("👤 Nombre:"));
        add(txtNombre);
        add(new JLabel("📧 Correo:"));
        add(txtCorreo);
        add(new JLabel("🔑 Contraseña:"));
        add(txtPass);
        add(btnRegistrar);
        add(btnVolver);

        btnRegistrar.addActionListener((ActionEvent e) -> {
            String nombre = txtNombre.getText();
            String correo = txtCorreo.getText();
            String pass = new String(txtPass.getPassword());

            if (nombre.isEmpty() || correo.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠️ Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                Usuario nuevo = new Usuario(nombre, correo, pass);
                JOptionPane.showMessageDialog(this, "🎉 ¡Registro exitoso!\nBienvenida, " + nombre + " 💕", "Registro", JOptionPane.INFORMATION_MESSAGE);
                dispose();
                new MenuUsuario(nuevo).setVisible(true);
            }
        });

        btnVolver.addActionListener((ActionEvent e) -> {
            dispose();
            new PantallaInicio().setVisible(true);
        });
    }
}

