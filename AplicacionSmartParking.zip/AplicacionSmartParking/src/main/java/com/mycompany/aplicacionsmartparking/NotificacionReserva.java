/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
public class NotificacionReserva {

    private Usuario usuario;
    private Reserva reserva;

    public NotificacionReserva(Usuario usuario, Reserva reservaActual) {
        this.usuario = usuario;
        this.reserva = reservaActual;
        verificarTiempoRestante();
    }

    // Método que verifica si el tiempo de la reserva está por terminar
    private void verificarTiempoRestante() {
        int minutosRestantes = reserva.getDuracionMinutos() - reserva.getMinutosTranscurridos();

        if (minutosRestantes <= 5 && minutosRestantes > 0) {
            mostrarNotificacion(minutosRestantes);
        } else if (minutosRestantes <= 0) {
            System.out.println("⚠️ Tu tiempo de reserva ya ha finalizado, " + usuario.getNombre() + ". Por favor renueva o libera el espacio.");
        }
    }

    // Método que imprime una notificación bonita
    private void mostrarNotificacion(int minutosRestantes) {
        System.out.println("🔔 ¡Hola " + usuario.getNombre() + "! ⏰");
        System.out.println("Tu reserva está por finalizar en " + minutosRestantes + " minutos.");
        System.out.println("Si deseas extender tu tiempo, ve a la sección de reservas para renovarla.");
        System.out.println("🅿️ ¡Gracias por usar SmartParking!");
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
