/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import java.util.Scanner;
import java.util.Random;

public class PagoEstacionamiento {

    private Usuario usuario;
    private Reserva reserva;
    private Scanner scanner;

    public PagoEstacionamiento(Usuario usuario, Reserva reservaActual) {
        this.usuario = usuario;
        this.reserva = reservaActual;
        this.scanner = new Scanner(System.in);

        iniciarPago();
    }

    // Método principal que gestiona el flujo de pago
    private void iniciarPago() {
        System.out.println("\n💳 MENÚ DE PAGO - SmartParking");
        System.out.println("Usuario: " + usuario.getNombre());
        System.out.println("Total a pagar: $" + reserva.getCosto());

        System.out.println("\nSelecciona el método de pago:");
        System.out.println("1. Tarjeta 💳");
        System.out.println("2. Efectivo 💵");

        System.out.print("Ingresa tu opción: ");
        int opcion = scanner.nextInt();

        switch (opcion) {
            case 1 -> pagarConTarjeta();
            case 2 -> pagarEnEfectivo();
            default -> {
                System.out.println("❌ Opción inválida. Intenta nuevamente.");
                iniciarPago();
            }
        }
    }

    // Método de pago con tarjeta
    private void pagarConTarjeta() {
        System.out.println("Procesando pago con tarjeta... 💳");
        System.out.println("✅ Pago realizado con éxito. ¡Gracias por tu preferencia, " + usuario.getNombre() + "!");
    }

    // Método de pago en efectivo (genera código)
    private void pagarEnEfectivo() {
        String codigoPago = generarCodigo();
        System.out.println("🧾 Por favor dirígete al cajero e ingresa el siguiente código para completar tu pago:");
        System.out.println("🔐 Código de Pago: " + codigoPago);
        System.out.println("✅ Una vez realizado, tu reserva será confirmada. ¡Gracias, " + usuario.getNombre() + "!");
    }

    // Método para generar un código de pago aleatorio
    private String generarCodigo() {
        Random random = new Random();
        int codigo = 100000 + random.nextInt(900000); // 6 dígitos
        return String.valueOf(codigo);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
