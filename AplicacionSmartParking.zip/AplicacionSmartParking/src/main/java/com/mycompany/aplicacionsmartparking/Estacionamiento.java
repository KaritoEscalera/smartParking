/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
public class Estacionamiento {
    private int id;
    private boolean disponible;

    public Estacionamiento(int id) {
        this.id = id;
        this.disponible = true;
    }

    public int getId() {
        return id;
    }

    public boolean estaDisponible() {
        return disponible;
    }

    public void ocupar() {
        disponible = false;
    }

    public void liberar() {
        disponible = true;
    }

    @Override
    public String toString() {
        return "Espacio #" + id + " | " + (disponible ? "Disponible" : "Ocupado");
    }
}
