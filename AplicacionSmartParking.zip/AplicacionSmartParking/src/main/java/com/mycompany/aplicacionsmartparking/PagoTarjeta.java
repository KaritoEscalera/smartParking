/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
public class PagoTarjeta extends Pago {

    private String numeroTarjeta;

    public PagoTarjeta(double monto, String fecha, String numeroTarjeta) {
        super(monto, fecha);
        this.numeroTarjeta = numeroTarjeta;
    }

    // Método para procesar el pago con tarjeta

    /**
     *
     */
    @Override
    public void procesarPago() {
        System.out.println("\n💳 Procesando pago con tarjeta...");
        System.out.println("🔢 Número de tarjeta: **** **** **** " + obtenerUltimosDigitos());
        System.out.println("💲 Monto: $" + getMonto());
        System.out.println("📅 Fecha: " + getFecha());
        System.out.println("✅ ¡Pago exitoso! Gracias por usar SmartParking 💜");
    }

    // Método auxiliar para ocultar la tarjeta y mostrar solo los últimos 4 dígitos
    private String obtenerUltimosDigitos() {
        if (numeroTarjeta.length() >= 4) {
            return numeroTarjeta.substring(numeroTarjeta.length() - 4);
        } else {
            return "XXXX";
        }
    }
}
