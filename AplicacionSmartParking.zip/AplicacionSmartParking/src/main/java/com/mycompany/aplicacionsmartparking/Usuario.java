/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
public class Usuario {
    private String nombre;
    private final String correo;
    private final String password;

    public Usuario(String nombre, String correo, String password) {
        this.nombre = nombre;
        this.correo = correo;
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean validarLogin(String correo, String pass) {
        return this.correo.equals(correo) && this.password.equals(pass);
    }

    @Override
    public String toString() {
        return nombre + " (" + correo + ")";
    }
}
