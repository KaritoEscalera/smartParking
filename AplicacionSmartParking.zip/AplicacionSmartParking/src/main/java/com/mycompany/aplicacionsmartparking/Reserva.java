/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aplicacionsmartparking;

/**
 *
 * @author claud
 */
import java.time.LocalDateTime;

public class Reserva {
    private Usuario usuario;
    private Estacionamiento espacio;
    private LocalDateTime horaInicio;
    private int duracionHoras;

    public Reserva(Usuario usuario, Estacionamiento espacio, int duracionHoras) {
        this.usuario = usuario;
        this.espacio = espacio;
        this.horaInicio = LocalDateTime.now();
        this.duracionHoras = duracionHoras;
        espacio.ocupar();
    }

    public double calcularCosto() {
        return duracionHoras * 20.0;
    }

    public LocalDateTime getHoraFin() {
        return horaInicio.plusHours(duracionHoras);
    }

    public void extenderReserva(int horasExtras) {
        this.duracionHoras += horasExtras;
    }

    @Override
    public String toString() {
        return "Reserva de " + usuario.getNombre() + " | Espacio #" + espacio.getId() +
               " | Desde: " + horaInicio + " | Hasta: " + getHoraFin() +
               " | Total: $" + calcularCosto();
    }

    int getDuracionMinutos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int getMinutosTranscurridos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getCosto() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
